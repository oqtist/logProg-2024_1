const botao = document.querySelector('button')
const caixa = document.querySelector('#caixa')

botao.onclick = () => {
    caixa.style.backgroundColor = 'green'
}